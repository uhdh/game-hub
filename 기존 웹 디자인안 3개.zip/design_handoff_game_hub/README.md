# Handoff: 게임 허브 (Game Hub) 홈 화면

## Overview
모바일 폭(~430px)의 게임 목록 랜딩 화면. 사용자가 게임 카드를 선택해 각 게임으로 이동한다. 카드 목록은 계속 늘어날 예정.

## About the Design Files
이 번들의 `.dc.html` 파일들은 **디자인 레퍼런스로 만든 HTML 프로토타입**이다. 실제 배포 코드로 그대로 복사하지 말 것. 목표는 이 HTML이 보여주는 룩앤필과 동작을 대상 코드베이스(React/Vue/Native 등, 이미 있는 스택)의 기존 패턴과 라이브러리를 사용해 재구현하는 것이다. 스택이 아직 없다면 프로젝트에 가장 적합한 프레임워크를 선택해 구현한다.

## Fidelity
**High-fidelity.** 색상, 타이포그래피, spacing, 인터랙션이 최종안에 가깝다. 픽셀 단위로 재현할 것.

## Screens / Views

### 1. Home (게임 허브)
- **Purpose**: 게임 목록을 보여주고 각 게임으로 진입시키는 랜딩 화면.
- **Layout**: 뷰포트 전체 높이, 세로 중앙 정렬된 최대폭 430px 컬럼. 바깥 padding `32px 16px 48px`. 배경 `#0f0f12`.
  - 헤더 블록 (상단 텍스트 3줄, gap 6px)
  - 게임 카드 리스트 (세로 flex, gap 14px)
  - 리스트 맨 아래 "더 많은 게임이 곧 추가됩니다" 안내 박스 (dashed border)
- **Components**:
  - **헤더**: eyebrow 라벨(현재 비어있음 — 이전엔 "Game Hub" 텍스트, 사용자가 직접 삭제함), 타이틀 "피의 게임 X 시뮬레이터" (26px/800/`#e7ebee`), 서브텍스트 "계속 새로운 게임이 추가됩니다." (13px/`#8992a0`)
  - **게임 카드** (`<a>` 링크, 클릭 시 이동):
    - 배경 `#15181c`, border `1px solid rgba(255,255,255,.06)`, border-radius 18px, padding `14px 16px`, shadow `0 12px 30px rgba(0,0,0,.35)`
    - hover: border-color `rgba(95,184,176,.4)`
    - 가로 flex: [아이콘 56×56] — [제목+설명, flex:1] — [화살표 "→"]
    - 제목: 16.5px/700/`#e7ebee`. 설명: 12.5px/`#8992a0`, 1줄 말줄임.
    - **아이콘 타입 A (quads)**: 2×2 컬러 타일 그리드(모자이크 게임 시각 아이덴티티), 배경 `#1c2024`, border `1px solid rgba(255,255,255,.08)`, radius 14px, 내부 gap 2px, 각 셀 radius 3px.
      - 팔레트: R `#c96a63`, Y `#d3b263`, G `#5ca892`, B `#5b8fc4`
      - "재배치" 카드는 4번째 셀을 `transparent`로 처리해 "블록 1개 빠짐"을 표현
    - **아이콘 타입 B (image slot)**: 56×56 rounded(14px) 이미지. 돈벌레 게임 카드에 사용, 기본 이미지 `assets/donbeolle-1.png` (금화+벌레 아이콘), 사용자가 드래그앤드롭으로 교체 가능한 플레이스홀더 컴포넌트(`image-slot.js`)로 구현되어 있음 — 실제 앱에선 일반 `<img>` 또는 이미지 업로드 컴포넌트로 대체.
  - **카드 순서/데이터**:
    1. 모자이크 퍼즐 — desc "컬러 타일을 이어붙여 최고 점수를 노려보세요" — 외부 링크 `https://color-connect-solo.vercel.app/` (새 탭)
    2. 모자이크 퍼즐 - 재배치 — desc "타일을 배치하고 재배치해 점수를 완성하세요" — 내부 링크 `Color Connect - Rearrange.dc.html` (같은 탭)
    3. 돈벌레 게임 — desc "베팅하고 굴려서 배당을 노려보세요" — 외부 링크 `https://cockroach-gambling-board.web.app/` (새 탭)
  - **빈 안내 박스**: dashed border `1px dashed rgba(255,255,255,.1)`, radius 18px, padding 16px, 텍스트 "더 많은 게임이 곧 추가됩니다" (13px/`#5b6270`), 중앙 정렬.

### 2. Color Connect - Prototype (모자이크 퍼즐 게임 본편)
전체 게임 플레이 화면(배치→슬라이딩→점수 등록→리더보드). 상세 스펙은 `Color Connect - Prototype.dc.html` 파일 자체를 참고 (인라인 스타일로 모든 값이 명시되어 있음). 핵심 컴포넌트:
- 상단 sticky 헤더: 타이틀, 스테이지 라벨 pill, "피의게임 재배치" 링크 버튼
- 스코어 스트립: 총점 큰 숫자(32px/800) + 색상별 알약 바 4개(각 바 아래 숫자)
- 4×4 보드 그리드, 드래그앤드롭/클릭으로 타일 배치, 15/16 타일 배치 후 15-puzzle 슬라이딩 모드로 전환
- 마켓(대기 타일) 3장 노출 + 회전 버튼, 이후 대기열 썸네일
- 점수 등록 → 모달(총점, top2 색상, 로컬 저장 리더보드 최대 10개)

### 3. Color Connect - Rearrange (피의게임 재배치)
Prototype과 동일한 2a 스타일 셸 재사용. 상세는 `Color Connect - Rearrange.dc.html` 참고.

## Interactions & Behavior
- 카드 클릭 → `href`로 이동 (`target`이 `_blank`인 경우 새 탭, `_self`인 경우 같은 탭 네비게이션)
- 카드 hover: border 색 변경만 (트랜지션 없음, 필요 시 추가)
- 리더보드: `localStorage` key `colorConnectSoloLeaderboard`에 `{score, ts}[]` JSON 저장, 점수 내림차순 정렬 후 상위 10개 유지

## State Management
Home 화면은 정적 데이터(게임 목록 배열)만 렌더링 — 별도 상태 없음. 게임 화면들은 각자 로컬 상태(보드, 대기열, 선택/드래그 상태, 모달, 리더보드)를 가짐 — 파일 내 로직 클래스 참고.

## Design Tokens
- 배경: `#0f0f12` (전체 배경), `#15181c` (카드/헤더), `#1c2024` (내부 패널), `#242a30` (버튼/타일 배경)
- 텍스트: `#e7ebee` (primary), `#8992a0` (secondary), `#5b6270` (dim)
- accent(teal): `#5fb8b0`, hover `#7fcac3`
- 보조 accent(blue): `#5b8fc4`
- 팔레트: R `#c96a63`, Y `#d3b263`, G `#5ca892`, B `#5b8fc4`
- Border: `rgba(255,255,255,.06~.14)` 계열 투명 흰색
- Radius: 카드 18px, 아이콘/보드 셀 14px, 버튼 8~10px, 보드 컨테이너 18px
- Shadow: 카드 `0 12px 30px rgba(0,0,0,.35)`
- 폰트: `-apple-system, 'Pretendard', 'Segoe UI', sans-serif`

## Assets
- `assets/donbeolle-1.png` — 돈벌레 게임 아이콘(금화+벌레), Canvas로 직접 생성한 플레이스홀더 아이콘. 실제 서비스에는 실제 사진/일러스트로 교체 권장.
- 모자이크 퍼즐 아이콘은 이미지 없이 CSS 그리드(2×2 컬러 타일)로 구현.

## Files
- `Home.dc.html` — 게임 허브 홈 화면
- `Color Connect - Prototype.dc.html` — 모자이크 퍼즐 게임 본편
- `Color Connect - Rearrange.dc.html` — 피의게임 재배치 화면
- `image-slot.js` — 드래그앤드롭 이미지 플레이스홀더 헬퍼(디자인 도구 전용, 실제 구현에서는 대체 필요)
